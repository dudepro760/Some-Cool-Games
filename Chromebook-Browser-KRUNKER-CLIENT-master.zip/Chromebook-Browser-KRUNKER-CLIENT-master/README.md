[![](https://forgivings.github.io/Chromebook-Browser-KRUNKER-CLIENT/sub.png)](http://www.youtube.com/forgivingkr?sub_confirmation=1 "Krunker Client Extension for Browser")
https://a-discount.github.io/Chromebook-Browser-KRUNKER-CLIENT/
# Krunker Client for Browser!
`The first KRUNKER CLIENT (As a form of an extension for launching purposes and easy access)`
``Us browser player have been looking for optimized and better gameplay experience, and here's the solution!
``**Please change the extension access to: cannot read site data**
Made by:
Discord: Discount#1188
Krunker Username: forgiving
Reddit: u/forgiving_
Discord: https://discord.io/kclan/
# What's NEW v0.8.9.99
- Optimization for FPS
- Added smoother gameplay by reducing some html events
- Cleaner Code
- Added Clan Button for Clan Games Krunker Update 2.6.9
# Loading the Chrome Extension
1. Download the ZIP file
2. Extract the folder Chromebook-Browser-KRUNKER-CLIENT-master and put it into your downloads
3. Go to chrome://extensions
4. turn on developer mode in the top right hand corner
5. Click on load unpacked
6. Select the folder Chromebook-Browser-KRUNKER-CLIENT-master
7. Go to the github site for more information
#
[![](http://img.youtube.com/vi/28naY7RTdYY/0.jpg)](http://www.youtube.com/watch?v=28naY7RTdYY "Krunker Client Extension for Browser")


