document.getElementById("myCredits").addEventListener("click", myFunction);
    function myFunction() {
  window.open("https://youtube.com/forgivingkr?sub_confirmation=1/", "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=500,left=500,width=675,height=400");
}