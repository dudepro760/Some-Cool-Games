document.getElementById("myCode").addEventListener("click", myFunction);
    function myFunction() {
  window.open("https://github.com/forgivings/Chromebook-Browser-KRUNKER-CLIENT", "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=500,left=500,width=675,height=400");
}
